package com.cg.mra.service;
//this package is packaged with service layer classes
import com.cg.mra.beans.Account;
import com.cg.mra.exceptions.AccountDetailsNotFoundException;
//interface of AccountService we need to implement this interface in AccountServiceImplementation class
public interface AccountService {
    Account getAccountDetails(String mobileNo) throws AccountDetailsNotFoundException;
    int rechargeAccount(String mobileNo,double rechargeAmount) throws AccountDetailsNotFoundException;
}
