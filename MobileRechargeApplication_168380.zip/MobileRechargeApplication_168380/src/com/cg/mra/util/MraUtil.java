package com.cg.mra.util;

import java.util.HashMap;
import java.util.Map;

import com.cg.mra.beans.Account;

public class MraUtil {

    public static Map<String, Account> accountEntry;
}
