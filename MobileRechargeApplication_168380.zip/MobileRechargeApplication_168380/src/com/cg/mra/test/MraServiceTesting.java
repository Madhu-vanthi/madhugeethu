
package com.cg.mra.test;

import static org.junit.BeforeClass.*;
import java.util.HashMap;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import com.cg.mra.beans.Account;
import com.cg.mra.dao.AccountDao;
import com.cg.mra.exceptions.AccountDetailsNotFoundException;
import com.cg.mra.service.AccountService;
import com.cg.mra.service.AccountServiceImpl;
public class MraServiceTesting {
    private static AccountDao mockAccountDao;
    private static AccountService accountService;
    @BeforeClass
    public static void setUpTestEnv() {
        accountService = new AccountServiceImpl();
    }
    @Before
    public void setUpTestData() {
        String mobile1 = "8428755275";
        String mobile2 = "9823920123";
        String mobile3 = "9566734579";
        Account account1 = new Account("Prepaid", "Madhu", 290);
        Account account2 = new Account("Prepaid", "Dinesh", 236);
        Account account3 = new Account("Prepaid", "Divya", 400);
        HashMap<String, Account> hashMap= new HashMap<>();
        hashMap.put(mobile1, account1);
        hashMap.put(mobile2, account2);
        hashMap.put(mobile3, account3);
    }
  

    @Test(expected=AccountDetailsNotFoundException.class)
    public void testGetAccountDetailsForInvalidMobileNo() throws AccountDetailsNotFoundException {
        Account actualDetails = accountService.getAccountDetails("123");        
    }

}
