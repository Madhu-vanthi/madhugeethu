package com.cg.mra.dao;

import com.cg.mra.beans.Account;
//DataAccess layer used for getting account details and recharge Accounts
public interface AccountDao {
    Account getAccountDetails(String mobileNo);//get account details
    int rechargeAccount(String mobileNo,double rechargeAmount);//recharge accounts
}
