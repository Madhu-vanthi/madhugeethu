package com.cg.mra.ui;

import java.util.Scanner;
import com.cg.mra.beans.Account;
import com.cg.mra.exceptions.AccountDetailsNotFoundException;
import com.cg.mra.service.AccountService;
import com.cg.mra.service.AccountServiceImpl;
//MainUI is to show the menu and acknowledge the details from client
// make object for administration class and execute the separate techniques
public class MainUI {
    public static void main(String[] args) {
        int choice,currentBalance,balance;
        double rechargeAmount;
        String mobileNo;
        Account account ;
//Scanner is a class in java.util package used for obtaining the input of the primitive types 
        Scanner scanner = new Scanner(System.in);
        AccountService accountService = new AccountServiceImpl(); 
        do {
            System.out.println("1. Account Balance Enquiry ");
            System.out.println("2. Recharge Account");
            System.out.println("3. Exit");
            choice = scanner.nextInt();
            scanner.nextLine();
            switch(choice) {
            case 1: System.out.println("Enter Mobile No : ");
            mobileNo = scanner.nextLine();
            try {
                account = accountService.getAccountDetails(mobileNo);
                System.out.println("Your Current Balance is Rs. "+account.getAccountBalance());
            } catch (AccountDetailsNotFoundException e) {}          
            break;
            case 2:System.out.println("Enter Mobile No : ");
            mobileNo = scanner.nextLine();
            System.out.println("Enter Recharge Amount : ");
            rechargeAmount = scanner.nextDouble();
            try {
                account = accountService.getAccountDetails(mobileNo);
                balance = accountService.rechargeAccount(mobileNo,rechargeAmount);
                System.out.println("Your Account Recharged Successfully");
                System.out.println("Hello "+account.getCustomerName()+",Available Balance is "+account.getAccountBalance());
            } catch (AccountDetailsNotFoundException e) {}


            break;
            case 3:
                System.exit(0);
            }
        }while(choice != 3);
    }
}



