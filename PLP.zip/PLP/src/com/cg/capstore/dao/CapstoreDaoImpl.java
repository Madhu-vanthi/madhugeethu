package com.cg.capstore.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;
import org.springframework.stereotype.Repository;

import com.cg.capstore.bean.Cart;
import com.cg.capstore.bean.Product;

@Repository
@Transactional
public class CapstoreDaoImpl implements ICapstoreDao{

	@PersistenceContext
	EntityManager entitymanager = null;	
	
	public CapstoreDaoImpl(){}
	
	public EntityManager getEntitymanager() {
		return entitymanager;
	}

	public void setEntitymanager(EntityManager entitymanager) {
		this.entitymanager = entitymanager;
	}	

	@Override
	public List<Cart> getCartDetails() {
		return entitymanager.createQuery("from Cart c").getResultList();
	}

	@Override
	public String orderPlacing(String product_id, int quantity) {
		Product product = entitymanager.find(Product.class, product_id);			
		if(product.getAvail_stock() >= quantity) return product_id;				
		else return null;
					
		
	}

}
