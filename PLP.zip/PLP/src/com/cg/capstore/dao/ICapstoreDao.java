package com.cg.capstore.dao;

import java.util.List;

import com.cg.capstore.bean.Cart;

public interface ICapstoreDao {

	public List<Cart> getCartDetails();
	public String orderPlacing(String product_id, int quantity);

}
