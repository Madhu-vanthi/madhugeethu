package com.cg.capstore.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.cg.capstore.bean.Cart;
import com.cg.capstore.bean.Product;
import com.cg.capstore.service.CapstoreServiceImpl;

@Controller
public class CapstoreControllerClass {

	@Autowired
	CapstoreServiceImpl CapService;

	public CapstoreServiceImpl getCapService() {
		return CapService;
	}

	public void setCapService(CapstoreServiceImpl capService) {
		CapService = capService;
	}

	@RequestMapping(value = "/cart", method=RequestMethod.GET)
	public String cartPage(Model model) {
		List<Cart> cart = CapService.getCartDetails();
		model.addAttribute("cartDetails", cart);
		return "CartPage";
	}
	
	@RequestMapping(value = "/placingOrder", method=RequestMethod.POST)
	public String OrderPlacement(@ModelAttribute(value="cartDetails")Cart cart, Model model) {
		String product_Id = CapService.orderPlacing(cart.getProducts().getProduct_id(), cart.getQuantity());
		if(product_Id != null)	return "ConfirmPage";
		else return "OrderNotPlaced";
	}

}