package com.cg.capstore.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.capstore.bean.Cart;
import com.cg.capstore.dao.CapstoreDaoImpl;

@Service
public class CapstoreServiceImpl implements ICapstoreService{

	@Autowired
	CapstoreDaoImpl capDao = null;
	
	public CapstoreServiceImpl() {}
	
	public CapstoreDaoImpl getCapDao() {
		return capDao;
	}

	public void setCapDao(CapstoreDaoImpl capDao) {
		this.capDao = capDao;
	}

	@Override
	public List<Cart> getCartDetails() {
		return capDao.getCartDetails();
	}

	@Override
	public String orderPlacing(String product_id, int quantity) {
		return capDao.orderPlacing(product_id, quantity);
	}
	
}
