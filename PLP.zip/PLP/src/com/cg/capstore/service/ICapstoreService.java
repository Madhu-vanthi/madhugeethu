package com.cg.capstore.service;

import java.util.List;
import com.cg.capstore.bean.Cart;

public interface ICapstoreService {

	public List<Cart> getCartDetails();
	public String orderPlacing(String product_id, int quantity);
}
