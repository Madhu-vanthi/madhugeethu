package com.cg.bean;

import java.util.ArrayList;

public class Employee {
private int employeeId,age;
private String employeeName;
private double salary;
private ArrayList<BusinessUnit>sbu;
public Employee() {}

public ArrayList<BusinessUnit> getSbu() {
	return sbu;
}

public void setSbu(ArrayList<BusinessUnit> sbu) {
	this.sbu = sbu;
}


public int getEmployeeId() {
	return employeeId;
}

public void setEmployeeId(int employeeId) {
	this.employeeId = employeeId;
}

public int getAge() {
	return age;
}

public void setAge(int age) {
	this.age = age;
}

public String getEmployeeName() {
	return employeeName;
}

public void setEmployeeName(String employeeName) {
	this.employeeName = employeeName;
}

public double getSalary() {
	return salary;
}

public void setSalary(double salary) {
	this.salary = salary;
}

}
