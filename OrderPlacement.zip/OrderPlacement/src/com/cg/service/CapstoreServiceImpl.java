package com.cg.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.bean.Cart;
import com.cg.bean.Product;
import com.cg.bean.User;
import com.cg.dao.ICapstoreDao;

@Service
public class CapstoreServiceImpl implements ICapstoreService{

	@Autowired
	ICapstoreDao capdao = null;

	public ICapstoreDao getCapdao() {
		return capdao;
	}

	public void setCapdao(ICapstoreDao capdao) {
		this.capdao = capdao;
	}

	@Override
	public Cart getCartDetails(String id) {
		return capdao.getCartDetails(id);
	}

	@Override
	public Product getProductDetails(String id) {
		return capdao.getProductDetails(id);
	}

	@Override
	public String checkAvailabilty(String id, int qty) {
		return capdao.checkAvailabilty(id, qty);
	}
	
	
}
