package com.cg.service;

import com.cg.bean.Cart;
import com.cg.bean.Product;

public interface ICapstoreService {

	public Cart getCartDetails(String id);
	public Product getProductDetails(String id);
	public String checkAvailabilty(String id, int qty);
}
