package com.cg.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;
import org.springframework.stereotype.Repository;

import com.cg.bean.Cart;
import com.cg.bean.Product;
import com.cg.bean.User;

@Repository
@Transactional
public class CapstoreDaoImpl implements ICapstoreDao{

	@PersistenceContext
	EntityManager entityManager=null;

	public EntityManager getEntityManager() {
		return entityManager;
	}

	public void setEntityManager(EntityManager entityManager) {
		this.entityManager = entityManager;
	}

	@Override
	public Cart getCartDetails(String id) {
		
		return (Cart) entityManager.createQuery("from Cart where Cart.user_id = id ").getSingleResult();
	}

	@Override
	public Product getProductDetails(String id) {
		return (Product) entityManager.createQuery("from Product where Product.product_id = id ").getSingleResult();
	}

	@Override
	public String checkAvailabilty(String id, int qty) {
		Product product = entityManager.find(Product.class, id);			
		if(product.getAvail_stock() >= qty) return id;				
		else return null;
	}
	
}
