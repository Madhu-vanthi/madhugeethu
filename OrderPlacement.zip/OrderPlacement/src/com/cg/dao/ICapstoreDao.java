package com.cg.dao;

import com.cg.bean.Cart;
import com.cg.bean.Product;

public interface ICapstoreDao {

	public Cart getCartDetails(String id);
	public Product getProductDetails(String id);
	public String checkAvailabilty(String id, int qty);

}
