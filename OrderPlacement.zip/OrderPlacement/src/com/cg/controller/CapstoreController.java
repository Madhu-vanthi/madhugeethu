package com.cg.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import com.cg.bean.Cart;
import com.cg.bean.Product;
import com.cg.bean.User;
import com.cg.service.ICapstoreService;

@Controller
public class CapstoreController {

	@Autowired
	ICapstoreService capService = null;

	public ICapstoreService getCapService() {
		return capService;
	}

	public void setCapService(ICapstoreService capService) {
		this.capService = capService;
	}
	
	@RequestMapping(value = "/cartPage", method=RequestMethod.GET)
	public String RetieveOperation(Model model ) {
		model.addAttribute("retrieve", new User());
		return "CartDetails";
	}
	
	@RequestMapping(value = "/RetrievalOfCart", method=RequestMethod.POST)
	public String RetrieveTraineeDetails(@ModelAttribute(value="retrieve")User usr , Model model ) {
		Cart cart = capService.getCartDetails(usr.getUser_id());
		Product product = capService.getProductDetails(cart.getProducts().getProduct_id());
		model.addAttribute("ct", cart);
		model.addAttribute("pd", product);
		return "CartDetails";
	}
	
	@RequestMapping(value = "/CheckStock", method=RequestMethod.POST)
	public String DisplayOfRetrievedDetails(@ModelAttribute(value="ct")Cart ct , Model model ) {
		String product_id = capService.checkAvailabilty(ct.getProducts().getProduct_id(), ct.getQuantity());
		if(product_id != null)	return "ConfirmPage";
		else return "OrderNotPlaced";
	}
}
