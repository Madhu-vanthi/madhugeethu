package com.cg.capstore.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.cg.capstore.bean.Cart;
import com.cg.capstore.bean.OrderItems;
import com.cg.capstore.service.InvoiceService;

@Controller
public class InvoiceController {

	@Autowired
	InvoiceService invoiceser;

	public InvoiceService getInvoiceser() {
		return invoiceser;
	}

	public void setInvoiceser(InvoiceService invoiceser) {
		this.invoiceser = invoiceser;
	}

	/*
	 * @RequestMapping(value = "InvoicePage", method = RequestMethod.GET) public
	 * String showInvoicePage(Model model) { List<Cart> cart=invoiceser.findCart();
	 * model.addAttribute("cart", cart); return "Invoice"; }
	 */
	@RequestMapping(value = "/InvoicePage", method = RequestMethod.GET)
	public String showInvoicePage(Model model) {
		List<OrderItems> orderItems = invoiceser.findOrderItems();
		model.addAttribute("orderItems", orderItems);
		return "Invoice";
	}
}