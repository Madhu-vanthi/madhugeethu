package com.cg.capstore.dao;

import java.util.List;

import com.cg.capstore.bean.Cart;
import com.cg.capstore.bean.OrderItems;

public interface InvoiceDao {
	
	 List<Cart> findCart(); 	
	 List<OrderItems> findOrderItems();
}