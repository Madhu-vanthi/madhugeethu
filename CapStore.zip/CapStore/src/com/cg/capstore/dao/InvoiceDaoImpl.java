package com.cg.capstore.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.cg.capstore.bean.Cart;
import com.cg.capstore.bean.OrderItems;

@Repository
@Transactional
public class InvoiceDaoImpl implements InvoiceDao {

	@PersistenceContext
	EntityManager entityManager;

public EntityManager getEntityManager() {
		return entityManager;
	}

	public void setEntityManager(EntityManager entityManager) {
		this.entityManager = entityManager;
	}

@Override
 public List<Cart> findCart() {
 return entityManager.createQuery("from Cart c").getResultList();
 }

@Override
public List<OrderItems> findOrderItems() {
	return entityManager.createQuery("from OrderItems i").getResultList();

}
}