package com.cg.capstore.service;
import java.util.List;
import com.cg.capstore.bean.Cart;
import com.cg.capstore.bean.OrderItems;
public interface InvoiceService {
	List<Cart> findCart(); 	
	List<OrderItems> findOrderItems();
}
