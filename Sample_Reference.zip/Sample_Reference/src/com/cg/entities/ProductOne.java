package com.cg.entities;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name="Ayushi")
public class ProductOne {
	
	@Id
	//@GeneratedValue(strategy=GenerationType.AUTO)
	private int productid;
	private String productname;
	private int customerid;
	private String rating_review; 
	private String rating_feedback;
	public int getProductid() {
		return productid;
	}
	public void setProductid(int productid) {
		this.productid = productid;
	}
	public int getCustomerid() {
		return customerid;
	}
	public void setCustomerid(int customerid) {
		this.customerid = customerid;
	}
	public String getRating_review() {
		return rating_review;
	}
	public void setRating_review(String rating_review) {
		this.rating_review = rating_review;
	}
	public String getRating_feedback() {
		return rating_feedback;
	}
	public void setRating_feedback(String rating_feedback) {
		this.rating_feedback = rating_feedback;
	}
	public String getProductname() {
		return productname;
	}
	public void setProductname(String productname) {
		this.productname = productname;
	}	
}





