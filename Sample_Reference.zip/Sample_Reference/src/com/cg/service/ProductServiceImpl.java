package com.cg.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import com.cg.dao.ProductDao;
import com.cg.dao.ProductDaoImpl;
import com.cg.entities.Cart;
import com.cg.entities.ProductOne;
@Service(value="productService")
public class ProductServiceImpl implements ProductService {
	
	@Autowired
	ProductDao productDao=new ProductDaoImpl();
	public ProductDao getProductDao() {
		return productDao;
	}
	public void setProductDao(ProductDao productDao) {
		this.productDao = productDao;
	}


	public List<ProductOne> getAllProducts() {
		return productDao.getAllProducts();
	}


	public ProductOne getProductById(String productId) {
		return productDao.getProductById(productId);
	}

	@Override
	public void editProduct(ProductOne product) {
		// TODO Auto-generated method stub

	}
	@Override
	public Object findAll() {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public Object find(int id) {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public Object updateCart(String cart) {
		
		return null;
	}
	@Override
	public Cart updateCart(Cart cart) {
		return productDao.updateCart(cart);
	}
	@Override
	public ProductOne getProductById(int productId) {
		
		return null;
	}
	@Override
	public ProductOne deleteProduct(int productId) {
		
		return productDao.deleteProduct(productId);
	}

	}
	




/*public void addProduct(Product product){
		productDao.addProduct(product);
	}
 */
